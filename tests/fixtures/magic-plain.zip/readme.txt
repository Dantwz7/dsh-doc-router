A plain zip container: not an Office file.
